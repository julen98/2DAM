package ejerciciosPropuestos89;

public interface IFiguraGeometrica {
	double CalculaArea();
	double CalculaPerimetro();
}
