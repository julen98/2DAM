package ejerciciosPropuestos89;

public interface IDibujable {
	void Dibujar();
}
